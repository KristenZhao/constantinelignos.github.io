# Welcome to an R script!
# This script contains both commands for R to evaluate and comments that R ignores (introduced by #).
# You can run each command one at a time or run the whole script at once (but that wouldn't be very practical).
# The script is divided into sections introduced with ##.

##
## Arithmetic, variables, and vectors 
##

#The simplest thing to do with R is use it as a calculator.
3 + 3
2 * 4
(369-1)/6
#R is not sensitive to spacing.
3+3

#You can also assign numbers to variables and calculate that way.
x = 5
yay = 10
x + yay
x - yay
yay - 7
#When you give R the name of a variable, it will tell you what value is assigned to that variable.
x
#Note that performing arithmetic on x has not changed x.
#R *is* sensitive to capitalisation.
X

#You can assign the output of a calculation to a variable too.
#When you do that, R doesn't print the answer when you perform the calculation -- the answer gets sucked into the variable instead.
answer = x + yay
#You can see the answer by giving R the name you assigned the answer to ('calling the variable').
answer

#You can also work with strings of numbers. A string of numbers is called a 'vector'.
#Put numbers in a vector using the c() ('concatenate') command. List the numbers you want to string together in the brackets, separated by commas.
#Assigning your vector to a variable is a shortcut that will prevent you from having to retype it every time.
vector = c(1,7,13,42)
vector
#You can do maths with vectors. This performs the maths operation on every element in the vector.
vector + 3
vector / 2
#To list numbers in order, use a : to separate the beginning and endpoints of the string you want.
vector2 = 1:4
vector2
#You can do maths with two vectors as long as the length of one is a multiple of the length of the other.
vector + vector2
vector3 = 1:5
vector2 + vector3 #oops! lengths are not multiples!
vector4 = 1:8
vector2 + vector4 #there we go!
#The shorter vector will repeat as many times as necessary to fit in the longer vector.

#You can access individual elements of a vector by 'indexing': picking out one or more members by its/their position in the list.
#An index is placed in square brackets.
vector[3] #3rd element of the variable 'vector'
#Again, you can use : to span the range between two numbers.
vector4[2:7] #2nd-7th elements of the variable 'vector'
#And, again, you can concatenate several noncontinuous numbers together using c().
vector4[c(1,4,7)] #1st, 4th, & 7th elements of the variable 'vector'

#What if you forget a bracket?
vector4[c(1,4,7)
#R will ask you to finish your command by giving you a +.
]
#You can always press escape to get out of this situation and start over with a new command.

#There are several mathematical functions that are useful to use on vectors.
#Functions in R require 'arguments': elements that the function will operate on.
#Arguments are placed in brackets next to the function name.
#In this case, spacing *does* matter: no space between the function name and the brackets containing the argument(s).
mean(vector)
mean(c(1,7,13,42)) #let's check R's maths
sum(vector2)
sum(1:4) #checking R's maths again
max(vector3)
min(vector4)

##
## Importing and manipulating data
##

#You can import data files into R.
#Your data file needs to be saved in CSV ('comma-separated values') or tab-delimited format.
#You can do this using the Save As command in Excel.
#Data files can be stored on your hard drive, or on the internet.
#(In the latter case, you'll need an internet connection to access them.)
#Let's import a CSV file of data on negative concord in Philadelphia.
data = read.csv("lcv_neg.csv")
#Note the inverted commas: they're required here.

#We can put a whole file of data into a single variable just like we put numbers and vectors into variables.
#In fact, this is the only way to manipulate data in R: by saving it into a variable first.
#If you call the variable you've loaded your data into, it will print as much of it as it can before it runs out of brain power.
data
#More useful, if you just want to make sure your data was read in properly, is to just look at chunks of it.
head(data) #print the first 6 rows
tail(data) #print the last 6 rows
#A variable of data with rows and columns like this is called a 'data frame'. You can think of it like an Excel spreadsheet.

#You can perform summary statistics on the data set as a whole.
nrow(data) #number of rows
ncol(data) #number of columns
colnames(data) #column names
summary(data) #summary for each column
#You can see from the summary that most columns contain continuous (i.e. numerical) data.
#For continuous data, summary() gives statistical summaries.
#But a few columns (Sex, Style) contain categorical data.
#For categorical data, summary() gives counts of the number of observations with each level (i.e. unique value).

#Just like we indexed vector elements with square brackets, you can index data frame elements.
#The syntax for this is dataFrameName[rowIndex, columnIndex]
data[5,4] #the value in row 5, column 4
#To index a whole row, leave the column index blank (but still include the comma).
data[5,] #row 5
#To index a whole column, leave the row index blank (but still include the comma).
data[,4] #column 4
#As before, you can use vectors to pull out multiple rows or columns.
data[1,4:6] #row 1, columns 4-6
data[c(1,3), 5:6] #rows 1 & 3, columns 5 & 6

#An easier way of indexing makes reference to column names rather than column index numbers.
#This way you don't have to count your columns every time you want to refer to one.
#The syntax here is dataFrameName$columnName. (USA! USA!)
data$Style
#A single column of a data set like this is a vector.
#Note that R indicates what its levels are (only applicable to vectors of categorical data).
#Since this is a vector, we can index it like any vector.
data$Style[5] #the 5th element of the Style column

#We saw a moment ago that Style has two levels, 'a' and 'b'.
#But what are style 'a' and 'b'? Not very informative labels!
#Let's rename them to something more useful.
#The levels function outputs a vector containing the level names for a vector of categorical data.
levels(data$Style)
#We can rename them by setting the output of the levels function equal to another vector with the names we want in it.
#The new names need to be in order corresponding to the old names.
levels(data$Style) = c("casual", "careful")
#Note the use of inverted commas.
#You need those when you're referring to a word rather than to a variable or a part of your data.
levels(data$Style)
#Let's double-check that that worked
data$Style[5] #used to be 'a', now it's 'casual'

#R has a handy function for making tables of counts.
table(data$Sex) #number of observations from each sex
#You can cross-tabulate two variables as well.
table(data$Neg, data$Style) #count for each variant of the dependent variable by style
#R has a handy function for calculating percentages in a table like this: prop.table()
#prop.table takes two arguments: a table, and the value 1 or 2.
#1 tells it to calculate percentages horizontally, and 2 to calculate percentages vertically.
prop.table(table(data$Neg, data$Style),1)
prop.table(table(data$Neg, data$Style),2) #Looks like there was more negative concord in casual style. As predicted!
#If you ever want to know which arguments a function takes, simply preface the function name with ? and a help document will appear.
?prop.table
#This isn't a great example because the help for prop.table isn't particularly helpful. Oh well...

#We can store tables in variables too:
negstyle = prop.table(table(data$Neg, data$Style),2)
negstyle

##
## Plotting
##

#Now is a good time to make a plot!
#A table of percentages like this is the perfect thing to put in a bar plot.
barplot(negstyle)
#What if we only want to plot the percentage of negative concord for each style, and not the complement percentage?
#It's the same procedure as indexing rows from a data frame!
barplot(negstyle[2,]) #row 2 of the negstyle table
#We can multiply the values by 100 to make them proper percentages.
barplot(negstyle[2,]*100)

#There are all sorts of ways to make our plots pretty.
#They all require adding arguments to the barplot function.
barplot(negstyle[2,]*100, ylim=c(0,100)) #set the y-axis limits from 0 to 100
barplot(negstyle[2,]*100, ylim=c(0,100), col = "blue") #blue bars!
barplot(negstyle[2,]*100, ylim=c(0,100), col = "blue", main = "Negative concord in Philadelphia") #give it a title
barplot(negstyle[2,]*100, ylim=c(0,100), col = "blue", main = "Negative concord in Philadelphia", ylab = "Percent negative concord") #label the y-axis
barplot(negstyle[2,]*100, ylim=c(0,100), col = "blue", main = "Negative concord in Philadelphia", ylab = "Percent negative concord", xlab = "Style") #label the x-axis
#There are all sorts of graphical parameters you can change with a bar plot.
#Learn about them with ?barplot

#We can also make scatter plots. This is done using the plot function.
#The plot function requires two arguments: the vector containing data to be plotted on the x-axis and the vector containing data to be plotted on the y-axis.
plot(data$Age, data$SEC) #plot socio-economic class (y-axis) by age (x-axis)
#Again, we can change the axis labels to something more intuitive, and add a title
plot(data$Age, data$SEC, xlab = "Age", ylab = "Socio-economic class", main = "Socio-economic class by age in a Philadelphia sample") #plot socio-economic class by age
#We can change the style of points by setting the pch argument equal to a number.
#Each number corresponds to a different point shape. This is admittedly somewhat obscure.
#Find a list of the numbers and their corresponding shapes at ?points
plot(data$Age, data$SEC, xlab = "Age", ylab = "Socio-economic class", main = "Socio-economic class by age in a Philadelphia sample", pch = 2)
plot(data$Age, data$SEC, xlab = "Age", ylab = "Socio-economic class", main = "Socio-economic class by age in a Philadelphia sample", pch = 16)
#And we can change the colour.
plot(data$Age, data$SEC, xlab = "Age", ylab = "Socio-economic class", main = "Socio-economic class by age in a Philadelphia sample", pch = 16, col = "pink")

#There are tons of parameters you can manipulate in a plot.
#e.g. text size, text colour, text direction, axis placement, tick mark placement...
#Learn about them all with ?par

#Want to add a regression line to your plot?
abline(lm(data$SEC ~ data$Age))
#Breaking this down:
#abline: adds a line to a plot. abline expects two arguments: the intercept and the slope of your line.
#lm: performs a linear regression analysis on your data. Data should be given in the form dependent_variable ~ independent_variable.
#Here, we're looking at whether socio-economic class (dependent variable) is a function of age (independent variable).
#The lm function returns a slope and an intercept, so it's the perfect thing to give as the argument to abline.
#As always, we can change graphical parameters of our line.
#But first we need to re-plot the graph without the line.
#This is because, otherwise, we'll just keep drawing lines on top of our existing line.
#Re-plotting the graph erases the line until we call abline again.
plot(data$Age, data$SEC, xlab = "Age", ylab = "Socio-economic class", main = "Socio-economic class by age in a Philadelphia sample", pch = 16, col = "pink")
abline(lm(data$SEC ~ data$Age), lty = 3, lwd = 3, col = "red") #make the line dashed (lty -- 'line type'), thick (lwd -- 'line width'), and red.
#As before, you can find all sorts of parameters for changing the appearance of your line in ?par

#A histogram of a vector is very easy to make in R.
hist(data$SEC)
#Excel can't do histograms. I kid you not.