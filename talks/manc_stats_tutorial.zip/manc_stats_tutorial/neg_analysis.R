library(lme4)

# Let's look at some negation data.
# Read it in.
neg <- read.csv('lcv_neg.csv')

# Eliminate collinearity. In this case, we're going to use residualization.
neg$rRes <- resid(lm(Res ~ Occ, neg))
neg$rSc2 <- resid(lm(Sc2 ~ Occ + rRes, neg))
neg$rSc1 <- resid(lm(Sc1 ~ Occ + rRes + rSc2, neg))
neg$rMo <- resid(lm(Mo ~ Occ + rRes + rSc2 + rSc1, neg))

# Center and standarize
neg$sOcc <- scale(neg$Occ)
neg$srRes <- scale(neg$rRes)
neg$srSc2 <- scale(neg$rSc2)
neg$srSc1 <- scale(neg$rSc1)
neg$srMo <- scale(neg$rMo)
neg$sAge <- scale(neg$Age)

# Fit a fixed effects model
m0 <- glm(Neg ~ sOcc + srRes + srSc2 + srSc1 + srMo + Sex + Style + sAge, neg, family = binomial)
summary(m0)

# Fit a mixed effects model
m1 <- lmer(Neg ~ sOcc + srRes + srSc2 + srSc1 + srMo + Sex + Style + sAge + (1 | Name), neg, family = binomial)
summary(m1)

# Now, let's have a discussion of what make good random/fixed effects in models.