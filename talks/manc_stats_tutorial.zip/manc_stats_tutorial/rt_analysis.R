# Load up the data
elp <- read.csv('elp_ldt_corrected.csv')

# Let's take a look at the basics
summary(elp)

# This looks odd. A number of predictors that should be numeric,
# like Freq_KF, NPhon, NSyll, etc. are not, notice the "(Other)"
# count instead of the mean. Looking at the data, it's because
# "NULL" was used when data were missing.

# Let's try again, using the na.strings option. This works nicely.
elp <- read.csv('elp_ldt_corrected.csv', na.strings = "NULL")
summary(elp)

# Some things to notice:
# 1. We have very few observations of some items. We might want to exclude
# these as they are less reliable.
# 2. Some items have frequency zero, or no pronunciation.
# Let's take a subset of the data where we can explore without running
# into these problems.
elp.clean <- subset(elp, !is.na(Freq_KF) & Freq_HAL > 0 & !is.na(Pron) & !is.na(I_Mean_RT))
summary(elp.clean)

# In interpreting the results of linear regression, one of the assumptions that we make
# is that predictors are independent (i.e., not multicollinear). If we want the
# regression to be useful, we should also check that a linear fit is a good way to go.

# How correlated is this data set? We can check this easily, but only
# if we narrow down to the numeric columns.
elp.numeric <- elp.clean[sapply(elp.clean, is.numeric)]
# Just ignore the NAs when computing this
cor(elp.numeric, use = "complete.obs")

# Alright, some basic models
mrt1 <- lm(I_Mean_RT ~ log(Freq_HAL), elp.clean)
summary(mrt1)

# Summary tells us frequency is significant. Not a bad start.
# Is this really a linear effect? Let's see:
plot(log(elp.clean$Freq_HAL), elp.clean$I_Mean_RT, ylab = "Item Mean RT", xlab = "Item Log HAL Frequency")
abline(mrt1, col = "blue")
lines(lowess(log(elp.clean$Freq_HAL), elp.clean$I_Mean_RT), col = "red")

# Note that if we hadn't used log on the predictor, it would be
# quite non-linear
plot(elp.clean$Freq_HAL, elp.clean$I_Mean_RT, ylab = "Item Mean RT", xlab = "Item HAL Frequency", xlim = c(0, 1000))
abline(mrt1, col = "blue")
lines(lowess(elp.clean$Freq_HAL, elp.clean$I_Mean_RT), col = "red")

# Another crucial assumption is that our errors are normally distributed. This
# means that the way our parameters were estimated is correct.

# Two ways of checking that our data is normally distributed.
# 1. Diagnostic QQ plot. You want to see that your curve
# is near the line. This is available as one of the plots
# if you just call plot(mrt1).
qqnorm(resid(mrt1))
qqline(resid(mrt1))

# We do see it pull away. Maybe a better model uses log?
mrt2 <- lm(log(I_Mean_RT) ~ log(Freq_HAL), elp.clean)
qqnorm(resid(mrt2))
qqline(resid(mrt2))

# Looks better. Is the actual fit better?
# By R^2, yes.
summary(mrt1)$r.squared
summary(mrt2)$r.squared

# 2. You can always just take a look:
hist(resid(mrt1), breaks = 100)
hist(resid(mrt2), breaks = 100)

# You might hear of so-called "normality tests," like
# Shapiro-Wilk. They are almost never of use. See:
# http://www.r-bloggers.com/normality-tests-don%E2%80%99t-do-what-you-think-they-do/

# Here's what something less normal looks like:
macc1 <- lm(I_Mean_Accuracy ~ log(Freq_HAL), elp.clean)
summary(macc1)
qqnorm(resid(macc1))
qqline(resid(macc1))
hist(resid(macc1), breaks = 100)
# There's a nasty low end.