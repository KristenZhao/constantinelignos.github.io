library(boot)
library(caTools)
library(e1071)

# Set the random seed so everyone gets the same result
set.seed(0)
# Give us ALL the decimal points!
options(digits=4)

# splitdata splits a frame into a list of training, test, and development frames
splitdata <- function(data, seed=0) {
  set.seed(seed)
  # Shuffle
  data.shuff = data[sample.int(nrow(data)),]
  # 60/20/20 split 
  # NB: The test and dev set can differ in size by one entry.
  # If that's a problem for you, write your own function.
  testindex <- trunc(nrow(data) * .2)
	devindex <- trunc(nrow(data) * .4)
  testset <- data.shuff[1:testindex,]
	devset <- data.shuff[(testindex + 1):devindex,]
	trainset <- data.shuff[(devindex + 1):nrow(data),]
	return(list(trainset=trainset, testset=testset, devset=devset))
}

# accuracy computes accuracy of classification
accuracy <- function(gold, predicted) {
  return(length(gold[gold == predicted]) / length(gold))
}

# Load in all our data and take a peek at it
boundaries <- read.table("brown_boundary_features_short.csv", header = TRUE, sep = ",")
summary(boundaries)

# Split into train, test, and dev.
splits <- splitdata(boundaries)
trainset <- splits$trainset
testset <- splits$testset
devset <- splits$devset

# First, check out the test set so we can come up with a baseline
summary(testset)
# Since it's heavily biased toward boundary=TRUE, try the simplest baseline
baseline.preds <- rep(TRUE, nrow(testset))
# Check the accuracy, not a bad place to start
accuracy(testset$Boundary, baseline.preds)

# Start with the simplest model, a decision stump based on TP
# Separate features from labels
trainfeatures <- subset(trainset, select = TP)
testfeatures <- subset(testset, select = TP)
trainlabels <- trainset$Boundary
testlabels <- testset$Boundary
# We're going to allow it only one training iteration. This makes it a simple stump.
boost.model <- LogitBoost(trainfeatures, trainlabels, nIter=1)
# Check out the predictions
boost.preds <- predict(boost.model, testfeatures)
table(boost.preds, testlabels) # Confusion matrix
accuracy(testlabels, boost.preds) # getting there!

# What if we just let it at it with all the features it wants?
trainfeatures <- subset(trainset, select = -Boundary)
testfeatures <- subset(testset, select = -Boundary)
boost.model <- LogitBoost(trainfeatures, trainlabels)
# Check out the predictions on train and test
# Train
boost.preds <- predict(boost.model, trainfeatures)
accuracy(trainlabels, boost.preds) 
# Test
boost.preds <- predict(boost.model, testfeatures)
accuracy(testlabels, boost.preds) 

# Let's switch to logistic regression
logit.model <- glm(Boundary ~ TP, data=trainset, family=binomial)
summary(logit.model)
logit.preds <- predict(logitmodel, testset)
logit.preds <- as.logical(sign(logit.preds) + 1) # Ugly hack to get TRUE/FALSE from +/-
accuracy(testlabels, logit.preds)

logit.model <- glm(Boundary ~ TP + StressBefore + StressAfter, data=trainset, family=binomial)
summary(logit.model)
logit.preds <- predict(logitmodel, testset)
logit.preds <- as.logical(sign(logit.preds) + 1) # Ugly hack to get TRUE/FALSE from +/-
accuracy(testlabels, logit.preds)

logit.model <- glm(Boundary ~ TP + StressBefore + StressAfter + log(LeftFreq) + log(RightFreq), data=trainset, family=binomial)
summary(logit.model)
logit.preds <- predict(logitmodel, testset)
logit.preds <- as.logical(sign(logit.preds) + 1) # Ugly hack to get TRUE/FALSE from +/-
accuracy(testlabels, logit.preds)

# Huh, LeftFreq isn't doing anything, can we get rid of it?
logit.model <- glm(Boundary ~ TP + StressBefore + StressAfter + log(RightFreq), data=trainset, family=binomial)
summary(logit.model)
logit.preds <- predict(logitmodel, testset)
logit.preds <- as.logical(sign(logit.preds) + 1)
accuracy(testlabels, logit.preds)

# That didn't help. I wonder whether logistic boosting was helped by it?
# What if we just let it at it with all the features it wants?
trainfeatures <- subset(trainset, select = c(-Boundary, -LeftFreq))
testfeatures <- subset(testset, select = c(-Boundary, -LeftFreq))
boost.model <- LogitBoost(trainfeatures, trainlabels)
# Check out the predictions on train and test
# Train
boost.preds <- predict(boost.model, trainfeatures)
accuracy(trainlabels, boost.preds) 
# Test
boost.preds <- predict(boost.model, testfeatures)
accuracy(testlabels, boost.preds)
# Improvement! Sometimes, removing useless features helps!


# Now let's get serious and play with an SVM
trainfeatures <- subset(trainset, select = -Boundary)
testfeatures <- subset(testset, select = -Boundary)
devfeatures <- subset(devset, select = -Boundary)
devlabels <- devset$Boundary
svm.model <- svm(Boundary ~ ., data = trainset, type = "C-classification")
# Check out the predictions on train and test
# Train
svm.preds <- predict(svm.model, trainset)
accuracy(trainlabels, svm.preds)
# Check out the predictions on train and test
# Test
svm.preds <- predict(svm.model, testset)
accuracy(testlabels, svm.preds)

# What a winner! Let's try some parameter searches. We'll use the dev set for
# validation and search some basic parameters
svm.tuned <- tune.svm(Boundary ~ ., data = trainset, type = "C-classification", 
                      gamma = 2^(-2:2), cost = 2^(0:6), validation.x = devfeatures,
                      validation.y = devlabels)
summary(svm.tuned)
plot(svm.tuned)
svm.preds <- predict(svm.tuned$best.model, testset)
accuracy(testlabels, svm.preds) # About as good as it gets!

# Finally, let's play with PCA
# You want scale = TRUE unless you have an extremely compelling reason. The only
# reason TRUE isn't default is for compatibility with S
boundaries.pca <- prcomp(~ TP + log(LeftFreq) + log(RightFreq), data = boundaries, scale = TRUE)
summary(boundaries.pca) # PC3 does account for some variance, but let's work with the first two for now
biplot(boundaries.pca)
print(boundaries.pca)

# Let's use the SVM again, now that we can visualize
# We're going to play fast and loose and just use the whole data set. Ideally we'd want to
# learn PCA on the training set, and then use it to predict the other sets.
boundaries$PC1 <- boundaries.pca$x[,1]
boundaries$PC2 <- boundaries.pca$x[,2]
svm.tuned <- tune.svm(Boundary ~ PC1 + PC2, data = boundaries, type = "C-classification", gamma = 2^(-1:3), cost = 2^(0:6))
plot(svm.tuned)
svm.preds <- predict(svm.tuned$best.model, boundaries)
plot(svm.tuned$best.model, data = boundaries, PC1 ~ PC2)
