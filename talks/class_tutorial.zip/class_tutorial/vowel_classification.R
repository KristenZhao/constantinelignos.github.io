library(rms)
library(class)
library(rpart)

# accuracy computes accuracy of classification
accuracy <- function(gold, predicted) {
  return(length(gold[gold == predicted]) / length(gold))
}

# Plot the gold data
plotgold <- function(data) {
  # Subset each vowel
  IY <- subset(data, Phoneme.Ascii == "IY")
  IH <- subset(data, Phoneme.Ascii == "IH")
  EH <- subset(data, Phoneme.Ascii == "EH")
  AE <- subset(data, Phoneme.Ascii == "AE")
  AH <- subset(data, Phoneme.Ascii == "AH")
  AA <- subset(data, Phoneme.Ascii == "AA")
  UH <- subset(data, Phoneme.Ascii == "UH")
  UW <- subset(data, Phoneme.Ascii == "UW")
  ER <- subset(data, Phoneme.Ascii == "ER")
  AO <- subset(data, Phoneme.Ascii == "AO")
  
  plot(0, 0, 'n', xlim=rev(c(550,2500)),ylim=rev(c(190,880)), xlab='F2', ylab='F1', main = "Peterson/Barney Vowels, Males")
  text(IY$F2, IY$F1, labels = "IY", cex = 0.6, col = "royalblue4")
  text(IH$F2, IH$F1, labels = "IH", cex = 0.6, col = "chartreuse4")
  text(EH$F2, EH$F1, labels = "EH", cex = 0.6, col = "coral4")
  text(AE$F2, AE$F1, labels = "AE", cex = 0.6, col = "cyan4")
  text(AH$F2, AH$F1, labels = "AH", cex = 0.6, col = "deeppink")
  text(AA$F2, AA$F1, labels = "AA", cex = 0.6, col = "darkorange")
  text(UH$F2, UH$F1, labels = "UH", cex = 0.6, col = "goldenrod")
  text(UW$F2, UW$F1, labels = "UW", cex = 0.6, col = "blue")
  text(ER$F2, ER$F1, labels = "ER", cex = 0.6, col = "darkorchid4")
  text(AO$F2, AO$F1, labels = "AO", cex = 0.6, col = "forestgreen")
}

# Plot the classification results for a set of data
plotperf <- function(data) {
  # Extract the errors
  errors <- subset(data, Phoneme.Ascii != Phoneme.predicted)
  
  # Group by predicted, not true labels
  IY <- subset(data, Phoneme.predicted == "IY")
  IH <- subset(data, Phoneme.predicted == "IH")
  EH <- subset(data, Phoneme.predicted == "EH")
  AE <- subset(data, Phoneme.predicted == "AE")
  AH <- subset(data, Phoneme.predicted == "AH")
  AA <- subset(data, Phoneme.predicted == "AA")
  UH <- subset(data, Phoneme.predicted == "UH")
  UW <- subset(data, Phoneme.predicted == "UW")
  ER <- subset(data, Phoneme.predicted == "ER")
  AO <- subset(data, Phoneme.predicted == "AO")
  
  # Place text of true label, color corresponding to predicted label
  # Plot data under classification
  plot(0, 0, 'n', xlim=rev(c(550,2500)),ylim=rev(c(190,880)), xlab='F2', ylab='F1', main = "Peterson/Barney Vowels, Males")
  text(IY$F2, IY$F1, labels = IY$Phoneme.Ascii, cex = 0.6, col = "royalblue4")
  text(IH$F2, IH$F1, labels = IH$Phoneme.Ascii, cex = 0.6, col = "chartreuse4")
  text(EH$F2, EH$F1, labels = EH$Phoneme.Ascii, cex = 0.6, col = "coral4")
  text(AE$F2, AE$F1, labels = AE$Phoneme.Ascii, cex = 0.6, col = "cyan4")
  text(AH$F2, AH$F1, labels = AH$Phoneme.Ascii, cex = 0.6, col = "deeppink")
  text(AA$F2, AA$F1, labels = AA$Phoneme.Ascii, cex = 0.6, col = "darkorange")
  text(UH$F2, UH$F1, labels = UH$Phoneme.Ascii, cex = 0.6, col = "goldenrod")
  text(UW$F2, UW$F1, labels = UW$Phoneme.Ascii, cex = 0.6, col = "blue")
  text(ER$F2, ER$F1, labels = ER$Phoneme.Ascii, cex = 0.6, col = "darkorchid4")
  text(AO$F2, AO$F1, labels = AO$Phoneme.Ascii, cex = 0.6, col = "forestgreen")
  
  # Throw some circles on the errors
  points(errors$F2, errors$F1, pch = 1, cex = 2.5, col = "red")
}

plotdecision <- function(data) {
  # Subset each vowel
  IY <- subset(data, Phoneme.Ascii == "IY")
  IH <- subset(data, Phoneme.Ascii == "IH")
  EH <- subset(data, Phoneme.Ascii == "EH")
  AE <- subset(data, Phoneme.Ascii == "AE")
  AH <- subset(data, Phoneme.Ascii == "AH")
  AA <- subset(data, Phoneme.Ascii == "AA")
  UH <- subset(data, Phoneme.Ascii == "UH")
  UW <- subset(data, Phoneme.Ascii == "UW")
  ER <- subset(data, Phoneme.Ascii == "ER")
  AO <- subset(data, Phoneme.Ascii == "AO")
  
  points(IY$F2, IY$F1, pch = 15, cex = 0.8, col = "royalblue4")
  points(IH$F2, IH$F1, pch = 15, cex = 0.8, col = "chartreuse4")
  points(EH$F2, EH$F1, pch = 15, cex = 0.8, col = "coral4")
  points(AE$F2, AE$F1, pch = 15, cex = 0.8, col = "cyan4")
  points(AH$F2, AH$F1, pch = 15, cex = 0.8, col = "deeppink")
  points(AA$F2, AA$F1, pch = 15, cex = 0.8, col = "darkorange")
  points(UH$F2, UH$F1, pch = 15, cex = 0.8, col = "goldenrod")
  points(UW$F2, UW$F1, pch = 15, cex = 0.8, col = "blue")
  points(ER$F2, ER$F1, pch = 15, cex = 0.8, col = "darkorchid4")
  points(AO$F2, AO$F1, pch = 15, cex = 0.8, col = "forestgreen")
}


# Load data
vowels.all <- read.table("verified_pb.data", header = TRUE, sep = "\t")

# Transform into factors
vowels.all$gender <- factor(vowels.all$M.F.C, levels = c(1, 2, 3), labels = c("M", "F", "C"))
vowels.all$M.F.C <- NULL
vowels.all$SPKR <- as.factor(vowels.all$SPKR)
vowels.all$Phoneme.Ascii <- as.factor(vowels.all$Phoneme.Ascii)

# Get rid of vowels that were not unanimously classified by humans and clean up the factor
vowels.good <- subset(vowels.all, substr(Phoneme.Ascii, 1, 1) != "*")
vowels.good$Phoneme.Ascii <- factor(vowels.good$Phoneme.Ascii)

# Trim down to Male data
vowels.good.M <- subset(vowels.good, gender == "M")
plotgold(vowels.good.M)

# Split out labels from rest
vowels.features <- subset(vowels.good.M, select = c(F1, F2))
vowels.labels <- vowels.good.M$Phoneme.Ascii

# First classifier: KNN
# Predict and merge the result back in
vowels.good.M$Phoneme.predicted <- knn.cv(vowels.features, vowels.labels, k = 5)
# Confusion matrix
table(vowels.labels, vowels.good.M$Phoneme.predicted)
# Plot how well we did
plotperf(vowels.good.M)
accuracy(vowels.good.M$Phoneme.Ascii, vowels.good.M$Phoneme.predicted)

# Next up: Decision tree
tree <- rpart(Phoneme.Ascii ~ F1 + F2, method = "class", data = vowels.good.M)
# Show the tree
plot(tree, compress=TRUE)
text(tree, cex=.8)
# Extract predictions
vowels.good.M$Phoneme.predicted <- predict(tree, type = "class")
accuracy(vowels.good.M$Phoneme.Ascii, vowels.good.M$Phoneme.predicted)
plotperf(vowels.good.M)
# Add in decision area by classifying lots of points
xp <- seq(min(vowels.good.M$F2), max(vowels.good.M$F2), length = 30)
yp <- seq(min(vowels.good.M$F1), max(vowels.good.M$F1), length = 30)
allpoints <- expand.grid(F2 = xp, F1 = yp)
allpoints$Phoneme.Ascii <- predict(tree, allpoints, type = "class")
plotdecision(allpoints)

# Let's go all out with an SVM!
svm.tuned <- tune.svm(Phoneme.Ascii ~ F1 + F2, data = vowels.good.M, type = "C-classification", 
                      gamma = 2^(-2:2), cost = 2^(0:6))
summary(svm.tuned)
plot(svm.tuned)
svm.preds <- predict(svm.tuned$best.model, testset)
accuracy(testset$Phoneme.Ascii, svm.preds)
plot(svm.tuned$best.model, data = vowels.good.M, F1 ~ F2, xlim=rev(c(550,2500)),ylim=rev(c(190,880)), xlab='F2', ylab='F1', main = "Peterson/Barney Vowels, Males")
